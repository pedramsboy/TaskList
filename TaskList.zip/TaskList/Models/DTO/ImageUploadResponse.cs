﻿namespace TaskList.Models.DTO
{
    public class ImageUploadResponse
    {
        public string ImageUrl { get; set; }
    }
}
